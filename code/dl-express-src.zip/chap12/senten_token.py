from nltk.tokenize import sent_tokenize	# 

text = "This is a house. This is a dog."		
print(sent_tokenize(text))	
