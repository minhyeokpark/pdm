from gtts import gTTS
tts = gTTS('hello')
tts.save('hello.mp3')